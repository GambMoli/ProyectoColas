import React from 'react'
import { MigrationControlSim } from './simulation'

export default function App() {
  return <MigrationControlSim />
}
